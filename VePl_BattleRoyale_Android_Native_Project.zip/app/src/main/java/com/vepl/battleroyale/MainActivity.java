package com.vepl.battleroyale;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    ToneGenerator audio;
    GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        audio = new ToneGenerator(AudioManager.STREAM_MUSIC, 85);
        game = new GameView(this);
        setContentView(game);
    }
    @Override public void onDestroy(){ if(audio!=null) audio.release(); super.onDestroy(); }

    class GameView extends View {
        Paint p=new Paint(3); Random rng=new Random();
        boolean playing=false, sprint=false, crouch=false, car=false, victory=false, defeat=false;
        float px=0, py=0, joyX=0, joyY=0, stickX=0, stickY=0, downX,downY;
        int hp=100, ammo=30, kills=0, enemies=12, diamonds=5555, selected=0;
        long last=System.currentTimeMillis();
        ArrayList<Bot> bots=new ArrayList<>();
        String message="Selamat datang di VePl Battle Royale";
        String menu="LOBBY";
        final String[] outfits={"ALPHA PHANTOM","NIGHT AGENT","STREET VOLT","CRIMSON FLAME","CYBER FROST"};
        class Bot { float x,y; int hp=100; boolean alive=true; Bot(float a,float b){x=a;y=b;} }
        GameView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void text(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));c.drawText(s,x,y,p);}
        void box(Canvas c,float x,float y,float w,float h,int color){p.setColor(color);c.drawRoundRect(x,y,x+w,y+h,12,12,p);}
        @Override protected void onDraw(Canvas raw){
            super.onDraw(raw); Canvas c=raw; float sx=getWidth()/1000f, sy=getHeight()/560f; c.save();c.scale(sx,sy);
            p.setShader(new LinearGradient(0,0,1000,560,Color.rgb(24,42,67),Color.rgb(7,10,22),Shader.TileMode.CLAMP));c.drawRect(0,0,1000,560,p);p.setShader(null);
            if(!playing){
                // hangar/lobby skyline
                p.setColor(Color.rgb(38,60,78)); c.drawRect(0,290,1000,560,p);
                p.setColor(Color.rgb(72,91,96)); for(int i=0;i<12;i++) c.drawRect(i*90,230+(i%3)*20,i*90+55,330,p);
                text(c,"VEPL BATTLE ROYALE",28,42,28,Color.WHITE);text(c,"💎 "+diamonds,800,40,25,Color.CYAN);
                box(c,18,75,190,440,0xdd10182a);String[] labels={"PROFILE","VAULT","LUCK ROYALE","SENJATA","KENDARAAN","HUD / CONTROL"};
                for(int i=0;i<labels.length;i++){box(c,28,90+i*61,170,48,selected==i?0xffb47a1d:0xff263650);text(c,labels[i],42,120+i*61,17,Color.WHITE);}
                drawHero(c,510,300,1.6f);text(c,outfits[selected%outfits.length],405,470,21,Color.WHITE);
                box(c,770,430,205,90,0xffffc928);text(c,"START MATCH",798,482,27,Color.BLACK);
                box(c,770,80,205,250,0xdd10182a);text(c,"PROFILE",795,112,21,0xffffd15b);text(c,"Player"+(android.provider.Settings.Secure.getString(getContext().getContentResolver(),"android_id").hashCode()&9999),790,150,16,Color.WHITE);text(c,"ID lokal",790,178,15,Color.LTGRAY);text(c,"Rank: Bronze I",790,210,16,Color.WHITE);text(c,"Level: 1",790,240,16,Color.WHITE);text(c,"Like: 0",790,270,16,Color.WHITE);
                text(c,"Native Android demo • multiplayer server belum tersambung",250,535,15,Color.LTGRAY);
            }else{
                // ground and paths
                p.setColor(Color.rgb(105,133,81));c.drawRect(0,0,1000,560,p);
                p.setColor(Color.rgb(167,157,120));p.setStrokeWidth(34);c.drawLine(0,410,1000,180,p);c.drawLine(500,0,600,560,p);
                for(int i=0;i<35;i++){float x=((i*137+px*.2f)%1100+1100)%1100,y=((i*83+py*.2f)%600+600)%600;p.setColor(Color.rgb(42,93,52));c.drawCircle(x,y,12+(i%3)*3,p);}
                for(int i=0;i<18;i++){float x=((i*181+px*.12f)%1050+1050)%1050,y=((i*117+py*.12f)%580+580)%580;p.setColor(Color.rgb(63,65,68));c.drawRect(x,y,x+42,y+30,p);p.setColor(Color.rgb(135,101,66));c.drawRect(x-4,y-5,x+46,y+3,p);}
                for(Bot b:bots){if(!b.alive)continue;float x=500+(b.x-px)*.38f,y=280+(b.y-py)*.38f;if(x<-20||x>1020||y<-20||y>580)continue;p.setColor(Color.rgb(235,231,218));c.drawCircle(x,y,11,p);p.setColor(Color.RED);c.drawRect(x-12,y-19,x+12,y-15,p);p.setColor(Color.GREEN);c.drawRect(x-12,y-19,x-12+24*b.hp/100f,y-15,p);}
                drawHero(c,500,280,1);
                box(c,10,8,210,42,0xdd08111e);text(c,"HP "+hp+"   AMMO "+ammo,24,35,18,Color.WHITE);
                box(c,760,8,230,42,0xdd08111e);text(c,"KILL "+kills+"   MUSUH "+enemies,778,35,18,Color.WHITE);
                box(c,10,60,330,34,0xbb08111e);text(c,message,20,82,14,Color.WHITE);
                // joystick and actions
                p.setColor(0x88405068);c.drawCircle(105,450,65,p);p.setColor(0xffc9eaff);c.drawCircle(105+joyX*30,450+joyY*30,23,p);
                String[] btn={"LARI","JONGKOK","LONCAT","TEMBAK","GANTI","LOOT","MOBIL","KELUAR"};
                for(int i=0;i<btn.length;i++){int col=i%4,row=i/4;float x=625+col*91,y=390+row*70;box(c,x,y,82,56,(i==3)?0xffb52c3b:0xdd101c30);text(c,btn[i],x+9,y+33,14,Color.WHITE);}
                if(victory||defeat){box(c,300,190,400,170,0xee080d1c);text(c,victory?"VICTORY":"DEFEAT",390,260,42,0xffffcf4b);text(c,"Tap untuk kembali ke lobby",370,300,18,Color.WHITE);}
            }
            c.restore();
            if(playing&&!victory&&!defeat){long now=System.currentTimeMillis();float dt=Math.min(2,(now-last)/16f);last=now;update(dt);postInvalidateDelayed(16);}
        }
        void drawHero(Canvas c,float x,float y,float scale){c.save();c.translate(x,y);c.scale(scale,scale);p.setColor(Color.rgb(239,241,243));Path coat=new Path();coat.moveTo(-24,-40);coat.lineTo(-42,45);coat.lineTo(-20,37);coat.lineTo(0,50);coat.lineTo(23,38);coat.lineTo(40,45);coat.lineTo(24,-40);coat.close();c.drawPath(coat,p);p.setColor(Color.rgb(210,166,48));p.setStrokeWidth(3);c.drawLine(-22,-35,-35,38,p);c.drawLine(22,-35,35,38,p);p.setColor(Color.rgb(185,190,201));c.drawCircle(0,-55,19,p);p.setColor(Color.rgb(34,37,47));c.drawRect(-17,-62,17,-48,p);p.setColor(Color.rgb(40,47,60));c.drawRect(-18,-18,18,38,p);p.setColor(Color.rgb(25,34,48));c.drawRect(-24,43,-5,90,p);c.drawRect(5,43,24,90,p);p.setColor(Color.rgb(245,194,51));c.drawRect(-24,82,-5,90,p);c.drawRect(5,82,24,90,p);p.setColor(Color.CYAN);p.setStrokeWidth(7);c.drawLine(12,-8,57,18,p);c.restore();}
        void update(float dt){if(!playing||victory||defeat)return;float sp=sprint?4.5f:2.5f;if(crouch)sp=1.2f;if(car)sp*=2.1f;px+=joyX*sp*dt;py+=joyY*sp*dt;
            for(Bot b:bots){if(!b.alive)continue;float dx=px-b.x,dy=py-b.y,d=(float)Math.hypot(dx,dy);if(d>25){b.x+=dx/(d+1)*.45f*dt;b.y+=dy/(d+1)*.45f*dt;}if(d<120&&Math.random()<.0015*dt){hp-=5;if(hp<=0){defeat=true;message="Kamu tereliminasi";}}}
            if(enemies<=0){victory=true;message="Semua musuh dikalahkan!";}
        }
        void shoot(){if(!playing||victory||defeat)return;if(ammo<=0){message="Peluru habis! Tekan isi ulang dengan LOOT";return;}ammo--;message="DOR! Tembakan "+ammo+" peluru tersisa";if(audio!=null)audio.startTone(ToneGenerator.TONE_DTMF_0,90);
            Bot target=null;float dmin=Float.MAX_VALUE;for(Bot b:bots)if(b.alive){float d=(float)Math.hypot(b.x-px,b.y-py);if(d<dmin){dmin=d;target=b;}}
            if(target!=null&&dmin<430){target.hp-=35;if(target.hp<=0){target.alive=false;kills++;enemies--;diamonds+=5;message="Bot tumbang! +5 diamond";}}
        }
        void start(){playing=true;victory=defeat=false;hp=100;ammo=30;kills=0;enemies=12;bots.clear();for(int i=0;i<enemies;i++)bots.add(new Bot(rng.nextInt(1000)-500,rng.nextInt(1000)-500));message="Terjun dari pesawat! Cari loot dan lawan bot.";last=System.currentTimeMillis();invalidate();}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX()*1000/getWidth(),y=e.getY()*560/getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;if(!playing){if(x>760&&y>420){start();return true;}if(x<220&&y>80&&y<470){selected=Math.max(0,Math.min(5,(int)((y-90)/61)));invalidate();return true;}return true;}
                if(victory||defeat){playing=false;victory=defeat=false;invalidate();return true;}
                if(x<230&&y>350){joyX=(x-105)/65;joyY=(y-450)/65;float d=(float)Math.hypot(joyX,joyY);if(d>1){joyX/=d;joyY/=d;}}
                else if(y>380&&x>610){int col=Math.min(3,Math.max(0,(int)((x-625)/91)));int row=y>455?1:0;int idx=row*4+col;
                    switch(idx){case 0:sprint=!sprint;message=sprint?"Lari aktif":"Lari nonaktif";break;case 1:crouch=!crouch;message=crouch?"Jongkok":"Berdiri";break;case 2:message="Melompat!";break;case 3:shoot();break;case 4:message="Senjata diganti";break;case 5:ammo=Math.min(60,ammo+10);message="Loot diambil +10 peluru";break;case 6:car=!car;message=car?"Masuk mobil":"Keluar mobil";break;case 7:playing=false;invalidate();break;}
                }invalidate();return true;
            }else if(e.getAction()==MotionEvent.ACTION_MOVE&&playing&&downX<230&&downY>350){joyX=Math.max(-1,Math.min(1,(x-105)/65));joyY=Math.max(-1,Math.min(1,(y-450)/65));invalidate();return true;}
            else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){joyX=joyY=0;invalidate();return true;}return true;}
    }
}