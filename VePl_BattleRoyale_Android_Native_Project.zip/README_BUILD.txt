VEPL BATTLE ROYALE — PROYEK ANDROID NATIVE (TANPA HTML)

Proyek ini adalah source project Android Studio native Java, bukan file APK yang sudah dikompilasi. Di lingkungan pembuatan ini Android SDK/Gradle tidak tersedia, jadi saya tidak bisa secara jujur memberikan APK siap instal dari sini.

Cara membangun APK:
1. Ekstrak ZIP di komputer.
2. Instal Android Studio versi stabil dan Android SDK Platform 35.
3. Buka folder VePl_BattleRoyale_Android sebagai project.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

Fitur native demo:
- Orientasi landscape dan fullscreen immersive.
- Lobby, menu profile/vault/luck royale/senjata/kendaraan/HUD versi prototipe.
- Arena 2D native, bot lokal, HP, kill, musuh, kontrol sentuh, lari/jongkok, mobil demo, victory/defeat.
- Efek suara tembakan sederhana memakai ToneGenerator Android.
- ID perangkat lokal sebagai demo, bukan akun online.

Batasan:
- Belum 3D, belum multiplayer online/server, belum akun cloud.
- ID lokal bukan sistem login dan tidak menyinkronkan progres lintas perangkat.
- Suara tembakan saat ini adalah efek nada sintetis sederhana, bukan rekaman senjata realistis.
- Model karakter digambar sederhana di Canvas; gambar referensi tidak otomatis menjadi model 3D.
